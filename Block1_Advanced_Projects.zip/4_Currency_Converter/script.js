function convert() {
  const amount = document.getElementById('amount').value;
  const to = document.getElementById('to').value;
  fetch('https://api.exchangerate-api.com/v4/latest/USD')
    .then(res => res.json())
    .then(data => {
      const rate = data.rates[to];
      document.getElementById('output').innerText = (amount * rate).toFixed(2) + ' ' + to;
    });
}
