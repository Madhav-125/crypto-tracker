function getWeather() {
  const city = document.getElementById('city').value;
  fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=YOUR_API_KEY&units=metric`)
    .then(res => res.json())
    .then(data => {
      document.getElementById('output').innerHTML = 
        `<p>Temp: ${data.main.temp} °C</p><p>${data.weather[0].description}</p>`;
    });
}
