fetch('https://newsapi.org/v2/top-headlines?country=in&apiKey=YOUR_API_KEY')
  .then(res => res.json())
  .then(data => {
    document.getElementById('news').innerHTML = data.articles.map(article => 
      `<div><h3>${article.title}</h3><p>${article.description}</p></div>`).join('');
  });
