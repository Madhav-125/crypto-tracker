function download() {
  const url = document.getElementById('url').value;
  document.getElementById('result').innerHTML = 'API setup required. Paste URL & call API here.';
}
